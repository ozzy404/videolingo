export { locales as middleware } from 'nextra/locales'

